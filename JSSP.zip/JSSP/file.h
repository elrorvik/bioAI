#pragma once

#pragma once

#include "operation_manager.h"

void read_file(std::string filename, int &n_jobs, int &n_machines, operation_seq_t& operation_seq);
void write_file(std::string filename, Operation_manager& om);